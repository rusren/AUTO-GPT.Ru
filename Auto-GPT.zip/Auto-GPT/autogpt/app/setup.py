"""Настройте AI и его цели"""
import re
from typing import Optional

from colorama import Fore, Style
from jinja2 import Template

from autogpt import utils
from autogpt.config import Config
from autogpt.config.ai_config import AIConfig
from autogpt.llm.base import ChatSequence, Message
from autogpt.llm.utils import create_chat_completion
from autogpt.logs import logger
from autogpt.prompts.default_prompts import (
    DEFAULT_SYSTEM_PROMPT_AICONFIG_AUTOMATIC,
    DEFAULT_TASK_PROMPT_AICONFIG_AUTOMATIC,
    DEFAULT_USER_DESIRE_PROMPT,
)


def prompt_user(
    config: Config, ai_config_template: Optional[AIConfig] = None
) -> AIConfig:
    """Запрашивать пользователя для ввода

    Params:
        config (Config): The Config object
        ai_config_template (AIConfig): The AIConfig object to use as a template

    Returns:
        AIConfig: The AIConfig object tailored to the user's input
    """

    # Создать подсказку
    logger.typewriter_log(
        "Добро пожаловать в Auto-GPT!",
        Fore.GREEN,
        "запустить с --help для получения дополнительной информации.",
        speak_text=True,
    )

    ai_config_template_provided = ai_config_template is not None and any(
        [
            ai_config_template.ai_goals,
            ai_config_template.ai_name,
            ai_config_template.ai_role,
        ]
    )

    user_desire = ""
    if not ai_config_template_provided:
        # Получить желание пользователя, если переопределения командной строки не были переданы
        logger.typewriter_log(
            "Создать AI-помощника:",
            Fore.GREEN,
            "введите '--manual', чтобы войти в ручной режим",
            speak_text=True,
        )

        user_desire = utils.clean_input(
            config, f"{Fore.LIGHTBLUE_EX}Я хочу, чтобы Auto-GPT{Style.RESET_ALL}: "
        )

    if user_desire.strip() == "":
        user_desire = DEFAULT_USER_DESIRE_PROMPT  # Подсказка по умолчанию

    # Если желание пользователя содержит "--manual" мы переопределили конфигурацию AI
    if "--manual" in user_desire or ai_config_template_provided:
        logger.typewriter_log(
            "Выбран ручной режим",
            Fore.GREEN,
            speak_text=True,
        )
        return generate_aiconfig_manual(config, ai_config_template)

    else:
        try:
            return generate_aiconfig_automatic(user_desire, config)
        except Exception as e:
            logger.typewriter_log(
                "Невозможно автоматически сгенерировать AI Config по желанию пользователя.",
                Fore.RED,
                "Возврат к ручному режиму.",
                speak_text=True,
            )
            logger.debug(f"Ошибка при генерации AIConfig: {e}")

            return generate_aiconfig_manual(config)


def generate_aiconfig_manual(
    config: Config, ai_config_template: Optional[AIConfig] = None
) -> AIConfig:
    """
    Интерактивно создавайте конфигурацию ИИ, предлагая пользователю указать имя, роль и цели AI.

    Эта функция направляет пользователя через серию подсказок для сбора необходимой информации для создания
     объект AIConfig. Пользователю будет предложено указать имя и роль для AI, а также до пяти
     целей. Если пользователь не укажет значение ни для одного из полей, будут использованы значения по умолчанию.

    Params:
        config (Config): Объект конфигурации
        ai_config_template (AIConfig): Объект AIConfig для использования в качестве шаблона

    Returns:
       AIConfig: объект AIConfig, содержащий заданное пользователем или заданное по умолчанию имя AI, роль и цели.
    """

    # Руководство по настройке вручную
    logger.typewriter_log(
        "Создать AI-помощника:",
        Fore.GREEN,
        "Введите имя вашего AI и его роль ниже. Если ничего не вводить, то загрузится"
        " значения по умолчанию.",
        speak_text=True,
    )

    if ai_config_template and ai_config_template.ai_name:
        ai_name = ai_config_template.ai_name
    else:
        ai_name = ""
        # Получить имя AI от пользователя
        logger.typewriter_log(
            "Имя вашего AI: ", Fore.GREEN, "Например, 'Предприниматель-GPT'"
        )
        ai_name = utils.clean_input(config, "Имя AI: ")
    if ai_name == "":
        ai_name = "Предприниматель-GPT"

    logger.typewriter_log(
        f"{ai_name} здесь!", Fore.LIGHTBLUE_EX, "Я к вашим услугам.", speak_text=True
    )

    if ai_config_template and ai_config_template.ai_role:
        ai_role = ai_config_template.ai_role
    else:
        # Получить роль AI от пользователя
        logger.typewriter_log(
            "Опишите роль вашего AI: ",
            Fore.GREEN,
            "Например, 'AI, предназначенный для развития и ведения бизнеса с единственной целью, увеличения собственного капитала.'",
        )
        ai_role = utils.clean_input(config, f"{ai_name} is: ")
    if ai_role == "":
        ai_role = "AI, предназначенный для развития и ведения бизнеса с единственной целью, увеличения собственного капитала."

    if ai_config_template and ai_config_template.ai_goals:
        ai_goals = ai_config_template.ai_goals
    else:
        # Введите до 5 целей для AI
        logger.typewriter_log(
            "Введите до 5 целей для AI: ",
            Fore.GREEN,
            "Например: \nУвеличивайте собственный капитал, развивайте учетную запись Twitter'",
        )
        logger.info("Ничего не вводите, чтобы загрузить значения по умолчанию.")
        ai_goals = []
        for i in range(5):
            ai_goal = utils.clean_input(
                config, f"{Fore.LIGHTBLUE_EX}Цель{Style.RESET_ALL} {i+1}: "
            )
            if ai_goal == "":
                break
            ai_goals.append(ai_goal)
    if not ai_goals:
        ai_goals = [
            "Увеличить собственный капитал",
            "Расширить аккаунт в Твиттере",
            "Автономно развивать несколько бизнесов и управлять ими",
        ]

    # Получить бюджет API от пользователя
    logger.typewriter_log(
        "Введите свой бюджет для вызовов API: ",
        Fore.GREEN,
        "Например: $1.50",
    )
    logger.info("Ничего не вводите, чтобы AI работал без ограничения")
    api_budget_input = utils.clean_input(
        config, f"{Fore.LIGHTBLUE_EX}Бюджет{Style.RESET_ALL}: $"
    )
    if api_budget_input == "":
        api_budget = 0.0
    else:
        try:
            api_budget = float(api_budget_input.replace("$", ""))
        except ValueError:
            logger.typewriter_log(
                "Недопустимый ввод бюджета. Установка бюджета на неограниченный.", Fore.RED
            )
            api_budget = 0.0

    return AIConfig(ai_name, ai_role, ai_goals, api_budget)


def generate_aiconfig_automatic(user_prompt: str, config: Config) -> AIConfig:
    """Генерирует объект AIConfig из заданной строки.

    Returns:
    AIConfig: Объект AIConfig, адаптированный к пользовательскому вводу
    """

    system_prompt = DEFAULT_SYSTEM_PROMPT_AICONFIG_AUTOMATIC
    prompt_ai_config_automatic = Template(
        DEFAULT_TASK_PROMPT_AICONFIG_AUTOMATIC
    ).render(user_prompt=user_prompt)
    # Вызов LLM со строкой в качестве пользовательского ввода
    output = create_chat_completion(
        ChatSequence.for_model(
            config.fast_llm,
            [
                Message("system", system_prompt),
                Message("user", prompt_ai_config_automatic),
            ],
        ),
        config,
    ).content

    # Отладка вывода LLM
    logger.debug(f"Исходный вывод генератора AI Config: {output}")

    # Проанализируйте вывод
    ai_name = re.search(r"Имя(?:\s*):(?:\s*)(.*)", output, re.IGNORECASE).group(1)
    ai_role = (
        re.search(
            r"Описание(?:\s*):(?:\s*)(.*?)(?:(?:\n)|Цели)",
            output,
            re.IGNORECASE | re.DOTALL,
        )
        .group(1)
        .strip()
    )
    ai_goals = re.findall(r"(?<=\n)-\s*(.*)", output)
    api_budget = 0.0  # TODO: анализировать бюджет API с помощью регулярного выражения

    return AIConfig(ai_name, ai_role, ai_goals, api_budget)
