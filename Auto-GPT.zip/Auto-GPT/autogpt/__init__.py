import os
import random
import sys

from dotenv import load_dotenv

if "pytest" in sys.argv or "pytest" in sys.modules or os.getenv("CI"):
    print("Установка случайного начального числа на 42")
    random.seed(42)

# Загрузите пользователей в файл .env и переменные среды.
load_dotenv(verbose=True, override=True)

del load_dotenv
