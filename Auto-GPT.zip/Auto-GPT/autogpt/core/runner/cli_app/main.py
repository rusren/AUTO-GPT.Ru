import click

from autogpt.core.agent import AgentSettings, SimpleAgent
from autogpt.core.runner.client_lib.logging import get_client_logger
from autogpt.core.runner.client_lib.parser import (
    parse_ability_result,
    parse_agent_name_and_goals,
    parse_agent_plan,
    parse_next_ability,
)


async def run_auto_gpt(user_configuration: dict):
    """Запустить клиент Auto-GPT CLI."""

    client_logger = get_client_logger()
    client_logger.debug("Получение настроек агента")

    agent_workspace = (
        user_configuration.get("workspace", {}).get("configuration", {}).get("root", "")
    )

    if not agent_workspace:  # We don't have an agent yet.
        #################
        # Начальная загрузка #
        #################
        # Шаг 1. Сопоставьте пользовательские настройки с системными настройками по умолчанию.
        agent_settings: AgentSettings = SimpleAgent.compile_settings(
            client_logger,
            user_configuration,
        )

        # Шаг 2. Получите имя и цели для агента.
        # Сначала нам нужно выяснить, что пользователь хочет делать с агентом.
        # Мы сделаем это, запросив у пользователя подсказку.
        user_objective = click.prompt("Что вы хотите, чтобы Auto-GPT делал?")
        # Попросите языковую модель определить имя и цели подходящего агента.
        name_and_goals = await SimpleAgent.determine_agent_name_and_goals(
            user_objective,
            agent_settings,
            client_logger,
        )
        print(parse_agent_name_and_goals(name_and_goals))
        # Наконец, обновите настройки агента, указав имя и цели.
        agent_settings.update_agent_name_and_goals(name_and_goals)

        # Шаг 3. Подготовьте агент.
        agent_workspace = SimpleAgent.provision_agent(agent_settings, client_logger)
        print("агент подготовлен")

    # цикл взаимодействия агента запуска
    agent = SimpleAgent.from_workspace(
        agent_workspace,
        client_logger,
    )
    print("агент загружен")

    plan = await agent.build_initial_plan()
    print(parse_agent_plan(plan))

    while True:
        current_task, next_ability = await agent.determine_next_ability(plan)
        print(parse_next_ability(current_task, next_ability))
        user_input = click.prompt(
            "Должен ли агент использовать эту способность?",
            default="y",
        )
        ability_result = await agent.execute_next_ability(user_input)
        print(parse_ability_result(ability_result))
