from __future__ import annotations

from pathlib import Path
from typing import Iterator

import orjson

from autogpt.config import Config
from autogpt.logs import logger

from ..memory_item import MemoryItem
from .base import VectorMemoryProvider


class JSONFileMemory(VectorMemoryProvider):
    """Бэкэнд памяти, который хранит воспоминания в файле JSON"""

    SAVE_OPTIONS = orjson.OPT_SERIALIZE_NUMPY | orjson.OPT_SERIALIZE_DATACLASS

    file_path: Path
    memories: list[MemoryItem]

    def __init__(self, config: Config) -> None:
        """Initialize a class instance

        Args:
            config: Config object

        Returns:
            None
        """
        self.file_path = config.workspace_path / f"{config.memory_index}.json"
        self.file_path.touch()
        logger.debug(
            f"Инициализирован {__class__.__name__} с индексным путем {self.file_path}"
        )

        self.memories = []
        try:
            self.load_index()
            logger.debug(f"Загруженные {len(self.memories)} элементы памяти из файла")
        except Exception as e:
            logger.warn(f"Не удалось загрузить MemoryItems из файла: {e}")
            self.save_index()

    def __iter__(self) -> Iterator[MemoryItem]:
        return iter(self.memories)

    def __contains__(self, x: MemoryItem) -> bool:
        return x in self.memories

    def __len__(self) -> int:
        return len(self.memories)

    def add(self, item: MemoryItem):
        self.memories.append(item)
        logger.debug(f"Добавление элемента в память: {item.dump()}")
        self.save_index()
        return len(self.memories)

    def discard(self, item: MemoryItem):
        try:
            self.remove(item)
        except:
            pass

    def clear(self):
        """Очищает данные в памяти."""
        self.memories.clear()
        self.save_index()

    def load_index(self):
        """Загружает все воспоминания из индексного файла"""
        if not self.file_path.is_file():
            logger.debug(f"Индексный файл '{self.file_path}' не существует")
            return
        with self.file_path.open("r") as f:
            logger.debug(f"Загрузка памяти из индексного файла '{self.file_path}'")
            json_index = orjson.loads(f.read())
            for memory_item_dict in json_index:
                self.memories.append(MemoryItem(**memory_item_dict))

    def save_index(self):
        logger.debug(f"Сохранение индекса памяти в файл {self.file_path}")
        with self.file_path.open("wb") as f:
            return f.write(orjson.dumps(self.memories, option=self.SAVE_OPTIONS))
