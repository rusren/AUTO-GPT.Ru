def parse_agent_name_and_goals(name_and_goals: dict) -> str:
    parsed_response = f"Имя Агента: {name_and_goals['agent_name']}\n"
    parsed_response += f"Роль Агента: {name_and_goals['agent_role']}\n"
    parsed_response += "Цели Агента:\n"
    for i, goal in enumerate(name_and_goals["agent_goals"]):
        parsed_response += f"{i+1}. {goal}\n"
    return parsed_response


def parse_agent_plan(plan: dict) -> str:
    parsed_response = f"План Агента:\n"
    for i, task in enumerate(plan["task_list"]):
        parsed_response += f"{i+1}. {task['objective']}\n"
        parsed_response += f"Тип задачи: {task['type']}  "
        parsed_response += f"Приоритет: {task['priority']}\n"
        parsed_response += f"Готовые Критерии:\n"
        for j, criteria in enumerate(task["ready_criteria"]):
            parsed_response += f"    {j+1}. {criteria}\n"
        parsed_response += f"Критерии Приемки:\n"
        for j, criteria in enumerate(task["acceptance_criteria"]):
            parsed_response += f"    {j+1}. {criteria}\n"
        parsed_response += "\n"

    return parsed_response


def parse_next_ability(current_task, next_ability: dict) -> str:
    parsed_response = f"Текущая задача: {current_task.objective}\n"
    ability_args = ", ".join(
        f"{k}={v}" for k, v in next_ability["ability_arguments"].items()
    )
    parsed_response += f"Следующая Способность: {next_ability['next_ability']}({ability_args})\n"
    parsed_response += f"Мотивация: {next_ability['motivation']}\n"
    parsed_response += f"Самокритика: {next_ability['self_criticism']}\n"
    parsed_response += f"Рассуждение: {next_ability['reasoning']}\n"
    return parsed_response


def parse_ability_result(ability_result) -> str:
    parsed_response = f"Способность: {ability_result['ability_name']}\n"
    parsed_response += f"Аргументы Способности: {ability_result['ability_args']}\n"
    parsed_response += f"Способность Результат: {ability_result['success']}\n"
    parsed_response += f"Сообщение: {ability_result['message']}\n"
    parsed_response += f"Данные: {ability_result['new_knowledge']}\n"
    return parsed_response
