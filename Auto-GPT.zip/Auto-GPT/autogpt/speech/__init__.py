"""Этот модуль содержит функцию распознавания речи и синтеза речи."""
from autogpt.speech.say import say_text

__all__ = ["say_text"]
