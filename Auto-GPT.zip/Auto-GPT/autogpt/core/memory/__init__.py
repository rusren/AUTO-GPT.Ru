"""Подсистема памяти управляет долговременной памятью Агента."""
from autogpt.core.memory.base import Memory
from autogpt.core.memory.simple import MemorySettings, SimpleMemory
