from autogpt.core.configuration import SystemConfiguration, UserConfigurable
from autogpt.core.planning.base import PromptStrategy
from autogpt.core.planning.schema import (
    LanguageModelClassification,
    LanguageModelPrompt,
)
from autogpt.core.planning.strategies.utils import json_loads
from autogpt.core.resource.model_providers import (
    LanguageModelFunction,
    LanguageModelMessage,
    MessageRole,
)


class NameAndGoalsConfiguration(SystemConfiguration):
    model_classification: LanguageModelClassification = UserConfigurable()
    system_prompt: str = UserConfigurable()
    user_prompt_template: str = UserConfigurable()
    create_agent_function: dict = UserConfigurable()


class NameAndGoals(PromptStrategy):
    DEFAULT_SYSTEM_PROMPT = (
        "Ваша работа состоит в том, чтобы реагировать на определяемую пользователем задачу, "
        "вызывая функцию `create_agent`, чтобы сгенерировать автономного агента для выполнения задачи. "
        "Вы должны указать имя агента на основе роли, информативное описание того, что делает агент, "
        "и от 1 до 5 целей, которые оптимально соответствуют успешному выполнению поставленной задачи.\n\n"
        "Пример ввода:\n"
        "Помогите мне с продвижением моего бизнеса\n\n"
        "Пример вызова функции:\n"
        "create_agent(name='CMOGPT', "
        "description='Профессиональный маркетолог с искусственным интеллектом, "
        "который помогает Solopreneurs в развитии их бизнеса, предоставляя опыт "
        "мирового уровня в решении маркетинговых проблем для SaaS, контент-продуктов, "
        "агентств и многого другого.', "
        "goals=['Engage in effective problem-solving, prioritization, planning, and "
        "Участвуйте в эффективном решении проблем, расстановке приоритетов, планировании "
        "и поддержке выполнения для удовлетворения моих маркетинговых потребностей в "
        "качестве моего виртуального отдела маркетинга.', 'Предоставляйте конкретные, "
        "действенные и краткие советы, которые помогут мне принимать обоснованные решения "
        "без использования банальностей или чрезмерно многословных объяснений.', "
        "'Предоставляйте мне конкретные, действенные и короткие советы, чтобы определить "
        "и расставить приоритеты для быстрых побед и рентабельных кампаний, которые максимизируют "
        "результаты с минимальными затратами времени и бюджета, помогите мне принять обоснованные "
        "решения без использования банальностей или чрезмерно многословных объяснений.', "
        "'Активно берите на себя инициативу, направляя меня и предлагая предложения, "
        "когда я сталкиваетесь с неясной информацией или неопределенностью, чтобы гарантировать, "
        "что моя маркетинговая стратегия остается в нужном русле.'])"
    )

    DEFAULT_USER_PROMPT_TEMPLATE = "'{user_objective}'"

    DEFAULT_CREATE_AGENT_FUNCTION = {
        "name": "create_agent",
        "description": ("Создайте нового автономного агента AI для выполнения заданной задачи."),
        "parameters": {
            "type": "object",
            "properties": {
                "agent_name": {
                    "type": "string",
                    "description": "Короткое ролевое имя для автономного агента.",
                },
                "agent_role": {
                    "type": "string",
                    "description": "Информативное описание в одном предложении того, что делает агент AI.",
                },
                "agent_goals": {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 5,
                    "items": {
                        "type": "string",
                    },
                    "description": (
                        "От одной до пяти высокоэффективных целей, оптимально связанных с выполнением конкретной задачи."
                        "Количество и сложность целей должны соответствовать сложности основной задачи агента."
                    ),
                },
            },
            "required": ["agent_name", "agent_role", "agent_goals"],
        },
    }

    default_configuration = NameAndGoalsConfiguration(
        model_classification=LanguageModelClassification.SMART_MODEL,
        system_prompt=DEFAULT_SYSTEM_PROMPT,
        user_prompt_template=DEFAULT_USER_PROMPT_TEMPLATE,
        create_agent_function=DEFAULT_CREATE_AGENT_FUNCTION,
    )

    def __init__(
        self,
        model_classification: LanguageModelClassification,
        system_prompt: str,
        user_prompt_template: str,
        create_agent_function: str,
    ):
        self._model_classification = model_classification
        self._system_prompt_message = system_prompt
        self._user_prompt_template = user_prompt_template
        self._create_agent_function = create_agent_function

    @property
    def model_classification(self) -> LanguageModelClassification:
        return self._model_classification

    def build_prompt(self, user_objective: str = "", **kwargs) -> LanguageModelPrompt:
        system_message = LanguageModelMessage(
            role=MessageRole.SYSTEM,
            content=self._system_prompt_message,
        )
        user_message = LanguageModelMessage(
            role=MessageRole.USER,
            content=self._user_prompt_template.format(
                user_objective=user_objective,
            ),
        )
        create_agent_function = LanguageModelFunction(
            json_schema=self._create_agent_function,
        )
        prompt = LanguageModelPrompt(
            messages=[system_message, user_message],
            functions=[create_agent_function],
            # TODO
            tokens_used=0,
        )
        return prompt

    def parse_response_content(
        self,
        response_content: dict,
    ) -> dict:
        """Анализ фактического текстового ответа из объективной модели.

        Args:
            response_content: The raw response content from the objective model.

        Returns:
            The parsed response.

        """
        parsed_response = json_loads(response_content["function_call"]["arguments"])
        return parsed_response
