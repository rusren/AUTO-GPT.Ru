from datetime import datetime


def get_datetime() -> str:
    """Вернуть текущую дату и время

    Returns:
        str: The current date and time
    """
    return "Текущая дата и время: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S")
