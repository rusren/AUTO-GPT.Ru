import functools
from pathlib import Path
from typing import Callable

from autogpt.agents.agent import Agent
from autogpt.logs import logger


def sanitize_path_arg(arg_name: str):
    def decorator(func: Callable):
        # Получить позицию параметра пути, если он передается как позиционный аргумент
        try:
            arg_index = list(func.__annotations__.keys()).index(arg_name)
        except ValueError:
            raise TypeError(
                f"Очищенный параметр '{arg_name}' отсутствует или не указана функция '{func.__name__}'"
            )

        # Получить позицию параметра агента, если он передается как позиционный аргумент
        try:
            agent_arg_index = list(func.__annotations__.keys()).index("agent")
        except ValueError:
            raise TypeError(
                f"Параметр 'agent' отсутствует или не указан в функции '{func.__name__}'"
            )

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            logger.debug(f"Sanitizing arg '{arg_name}' on function '{func.__name__}'")
            logger.debug(f"Function annotations: {func.__annotations__}")

            # Получить агент из аргументов вызываемой функции
            agent = kwargs.get(
                "agent", len(args) > agent_arg_index and args[agent_arg_index]
            )
            logger.debug(f"Аргументы: {args}")
            logger.debug(f"KWArgs: {kwargs}")
            logger.debug(f"Аргумент агента удален из вызова функции: {agent}")
            if not isinstance(agent, Agent):
                raise RuntimeError("Не удалось получить агент из аргументов декорированной команды")

            # Очистить указанный аргумент пути, если он задан
            given_path: str | Path | None = kwargs.get(
                arg_name, len(args) > arg_index and args[arg_index] or None
            )
            if given_path:
                if given_path in {"", "/"}:
                    sanitized_path = str(agent.workspace.root)
                else:
                    sanitized_path = str(agent.workspace.get_path(given_path))

                if arg_name in kwargs:
                    kwargs[arg_name] = sanitized_path
                else:
                    # args is an immutable tuple; must be converted to a list to update
                    arg_list = list(args)
                    arg_list[arg_index] = sanitized_path
                    args = tuple(arg_list)

            return func(*args, **kwargs)

        return wrapper

    return decorator
