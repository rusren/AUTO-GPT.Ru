import os
import re

import requests
import yaml
from colorama import Fore, Style
from git.repo import Repo
from prompt_toolkit import ANSI, PromptSession
from prompt_toolkit.history import InMemoryHistory

from autogpt.config import Config
from autogpt.logs import logger

session = PromptSession(history=InMemoryHistory())


def batch(iterable, max_batch_length: int, overlap: int = 0):
    """Пакетные данные из iterable в срезы длиной N. Последний пакет может быть короче."""
    # batched('ABCDEFG', 3) --> ABC DEF G
    if max_batch_length < 1:
        raise ValueError("n должен быть хотя бы один")
    for i in range(0, len(iterable), max_batch_length - overlap):
        yield iterable[i : i + max_batch_length]


def clean_input(config: Config, prompt: str = "", talk=False):
    try:
        if config.chat_messages_enabled:
            for plugin in config.plugins:
                if not hasattr(plugin, "can_handle_user_input"):
                    continue
                if not plugin.can_handle_user_input(user_input=prompt):
                    continue
                plugin_response = plugin.user_input(user_input=prompt)
                if not plugin_response:
                    continue
                if plugin_response.lower() in [
                    "да",
                    "ага",
                    "y",
                    "ok",
                    "хорошо",
                    "конечно",
                    "хорошо",
                ]:
                    return config.authorise_key
                elif plugin_response.lower() in [
                    "нет",
                    "неа",
                    "n",
                    "отрицательный",
                ]:
                    return config.exit_key
                return plugin_response

        # запросить ввод, по умолчанию, когда просто нажмите Enter, это y
        logger.info("Запрос пользователя через клавиатуру...")

        # handle_sigint must be set to False, so the signal handler in the
        # autogpt/main.py could be employed properly. This referes to
        # https://github.com/Significant-Gravitas/Auto-GPT/pull/4799/files/3966cdfd694c2a80c0333823c3bc3da090f85ed3#r1264278776
        answer = session.prompt(ANSI(prompt), handle_sigint=False)
        return answer
    except KeyboardInterrupt:
        logger.info("Вы прервали Auto-GPT")
        logger.info("Выход...")
        exit(0)


def validate_yaml_file(file: str):
    try:
        with open(file, encoding="utf-8") as fp:
            yaml.load(fp.read(), Loader=yaml.FullLoader)
    except FileNotFoundError:
        return (False, f"Файл {Fore.CYAN}`{file}`{Fore.RESET} не найден")
    except yaml.YAMLError as e:
        return (
            False,
            f"Возникла проблема при попытке чтения файла настроек AI: {e}",
        )

    return (True, f"Успешно подтверждено {Fore.CYAN}`{file}`{Fore.RESET}!")


def readable_file_size(size, decimal_places=2):
    """Преобразует заданный размер в байтах в читаемый формат.
    Args:
        size: Size in bytes
        decimal_places (int): Number of decimal places to display
    """
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024.0:
            break
        size /= 1024.0
    return f"{size:.{decimal_places}f} {unit}"


def get_bulletin_from_web():
    try:
        response = requests.get(
            "https://raw.githubusercontent.com/Significant-Gravitas/Auto-GPT/master/BULLETIN.md"
        )
        if response.status_code == 200:
            return response.text
    except requests.exceptions.RequestException:
        pass

    return ""


def get_current_git_branch() -> str:
    try:
        repo = Repo(search_parent_directories=True)
        branch = repo.active_branch
        return branch.name
    except:
        return ""


def get_latest_bulletin() -> tuple[str, bool]:
    exists = os.path.exists("data/CURRENT_BULLETIN.md")
    current_bulletin = ""
    if exists:
        current_bulletin = open(
            "data/CURRENT_BULLETIN.md", "r", encoding="utf-8"
        ).read()
    new_bulletin = get_bulletin_from_web()
    is_new_news = new_bulletin != "" and new_bulletin != current_bulletin

    news_header = Fore.YELLOW + "Добро пожаловать в Auto-GPT!\n"
    if new_bulletin or current_bulletin:
        news_header += (
            "Ниже вы найдете последние новости Auto-GPT и обновления, касающиеся функций!\n"
            "Если вы не хотите видеть это сообщение, вы можете запустить Auto-GPT с флагом *--skip-news*.\n"
        )

    if new_bulletin and is_new_news:
        open("data/CURRENT_BULLETIN.md", "w", encoding="utf-8").write(new_bulletin)
        current_bulletin = f"{Fore.RED}::НОВЫЙ БЮЛЛЕТЕНЬ::{Fore.RESET}\n\n{new_bulletin}"

    return f"{news_header}\n{current_bulletin}", is_new_news


def markdown_to_ansi_style(markdown: str):
    ansi_lines: list[str] = []
    for line in markdown.split("\n"):
        line_style = ""

        if line.startswith("# "):
            line_style += Style.BRIGHT
        else:
            line = re.sub(
                r"(?<!\*)\*(\*?[^*]+\*?)\*(?!\*)",
                rf"{Style.BRIGHT}\1{Style.NORMAL}",
                line,
            )

        if re.match(r"^#+ ", line) is not None:
            line_style += Fore.CYAN
            line = re.sub(r"^#+ ", "", line)

        ansi_lines.append(f"{line_style}{line}{Style.RESET_ALL}")
    return "\n".join(ansi_lines)


def get_legal_warning() -> str:
    legal_text = """
## ОТКАЗ ОТ ОТВЕТСТВЕННОСТИ И СОГЛАШЕНИЕ О ВОЗМЕЩЕНИИ ОТВЕТСТВЕННОСТИ
### ПОЖАЛУЙСТА, ВНИМАТЕЛЬНО ПРОЧИТАЙТЕ ЭТО ОТКАЗ ОТ ОТВЕТСТВЕННОСТИ И СОГЛАШЕНИЕ О ВОЗМЕЩЕНИИ ОТВЕТСТВЕННОСТИ ПЕРЕД ИСПОЛЬЗОВАНИЕМ СИСТЕМЫ AUTOGPT. ИСПОЛЬЗУЯ СИСТЕМУ AUTOGPT, ВЫ СОГЛАШАЕТЕСЬ СОБЛЮДАТЬ НАСТОЯЩЕЕ СОГЛАШЕНИЕ.

## Введение 
AutoGPT («Система») — это проект, который подключает систему искусственного интеллекта, подобную GPT, к Интернету и позволяет ей автоматизировать задачи. Хотя Система спроектирована так, чтобы быть полезной и эффективной, могут быть случаи, когда Система может выполнять действия, которые могут причинить вред или иметь непредвиденные последствия.

## Отсутствие ответственности за действия системы
Разработчики, участники и сопровождающие проекта AutoGPT (совместно именуемые «Стороны проекта») не дают никаких гарантий или заявлений, явных или подразумеваемых, относительно производительности, точности, надежности или безопасности Системы. Используя Систему, вы понимаете и соглашаетесь с тем, что Стороны проекта не несут ответственности за любые действия, предпринятые Системой, или любые последствия, вытекающие из таких действий.

## Ответственность пользователя и ответ Высшая ответственность
Как пользователь Системы, вы несете ответственность за контроль и мониторинг действий Системы, пока она работает на вашем
от имени. Вы признаете, что использование Системы может подвергнуть вас потенциальной ответственности, включая, помимо прочего, ответственность вышестоящего руководства, и вы соглашаетесь принять на себя все риски и обязательства, связанные с такой потенциальной ответственностью.

## Возмещение
Используя Систему, вы соглашаетесь возмещать убытки, защищать и ограждать Стороны проекта от любых и всех претензий, обязательств, убытков, убытков или расходов (включая разумные гонорары и расходы на адвокатов), возникающих из или в связи с использование вами Системы, включая, помимо прочего, любые действия, предпринятые Системой от вашего имени, любую неспособность должным образом контролировать или контролировать Систему и любой вытекающий из этого ущерб или непредвиденные последствия.
           """
    return legal_text
