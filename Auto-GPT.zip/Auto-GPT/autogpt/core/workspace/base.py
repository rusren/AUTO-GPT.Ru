from __future__ import annotations

import abc
import logging
import typing
from pathlib import Path

if typing.TYPE_CHECKING:
    from autogpt.core.configuration import AgentConfiguration


class Workspace(abc.ABC):
    """Рабочая область — это корневой каталог для всех сгенерированных файлов.

    Рабочая область отвечает за создание корневого каталога и предоставляет метод
    для получения полного пути к элементу в рабочей области.

    """

    @property
    @abc.abstractmethod
    def root(self) -> Path:
        """Корневой каталог рабочей области."""
        ...

    @property
    @abc.abstractmethod
    def restrict_to_workspace(self) -> bool:
        """Ограничивать ли сгенерированные пути к рабочей области."""
        ...

    @staticmethod
    @abc.abstractmethod
    def setup_workspace(
        configuration: AgentConfiguration, logger: logging.Logger
    ) -> Path:
        """Создайте корневой каталог рабочей области и настройте весь исходный контент.

        Parameters
        ----------
        configuration
            The Agent's configuration.
        logger
            The Agent's logger.

        Returns
        -------
        Path
            The path to the workspace root directory.

        """
        ...

    @abc.abstractmethod
    def get_path(self, relative_path: str | Path) -> Path:
        """Получить полный путь к элементу в рабочей области.

        Parameters
        ----------
        relative_path
            Путь к элементу относительно корня рабочей области.

        Returns
        -------
        Path
            Полный путь к элементу.

        """
        ...
