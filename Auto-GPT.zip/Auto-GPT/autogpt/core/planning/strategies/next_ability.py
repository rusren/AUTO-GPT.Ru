from autogpt.core.configuration import SystemConfiguration, UserConfigurable
from autogpt.core.planning.base import PromptStrategy
from autogpt.core.planning.schema import (
    LanguageModelClassification,
    LanguageModelPrompt,
    Task,
)
from autogpt.core.planning.strategies.utils import json_loads, to_numbered_list
from autogpt.core.resource.model_providers import (
    LanguageModelFunction,
    LanguageModelMessage,
    MessageRole,
)


class NextAbilityConfiguration(SystemConfiguration):
    model_classification: LanguageModelClassification = UserConfigurable()
    system_prompt_template: str = UserConfigurable()
    system_info: list[str] = UserConfigurable()
    user_prompt_template: str = UserConfigurable()
    additional_ability_arguments: dict = UserConfigurable()


class NextAbility(PromptStrategy):
    DEFAULT_SYSTEM_PROMPT_TEMPLATE = "Системная информация:\n{system_info}"

    DEFAULT_SYSTEM_INFO = [
        "ОС на которой вы работаете: {os_info}",
        "Чтобы позволить тебе бегать, нужны деньги. Ваш бюджет API составляет ${api_budget:.3f}",
        "Текущее время и дата {current_time}",
    ]

    DEFAULT_USER_PROMPT_TEMPLATE = (
        "Ваша текущая задача {task_objective}.\n"
        "Вы уже выполнили {cycle_count} действий по этой задаче. "
        "Вот действия, которые вы предприняли, и их результаты:\n"
        "{action_history}\n\n"
        "Вот дополнительная информация, которая может быть вам полезна:\n"
        "{additional_info}\n\n"
        "Кроме того, вы должны учитывать следующее:\n"
        "{user_input}\n\n"
        "Ваша задача {task_objective} завершена, если выполнены следующие критерии:\n"
        "{acceptance_criteria}\n\n"
        "Пожалуйста, выберите одну из предоставленных функций для выполнения этой задачи. "
        "Для выполнения некоторых задач может потребоваться несколько функций. "
        "Если это так, выберите функцию, которая, по вашему мнению, наиболее подходит для текущей ситуации, учитывая ваш прогресс."
    )

    DEFAULT_ADDITIONAL_ABILITY_ARGUMENTS = {
        "motivation": {
            "type": "string",
            "description": "Ваше обоснование выбора этой функции вместо другой.",
        },
        "self_criticism": {
            "type": "string",
            "description": "Вдумчивая самокритика, которая объясняет, почему эта функция может быть не лучшим выбором.",
        },
        "reasoning": {
            "type": "string",
            "description": "Ваши аргументы в пользу выбора этой функции с учетом `motivation` и взвешивания `self_criticism`.",
        },
    }

    default_configuration = NextAbilityConfiguration(
        model_classification=LanguageModelClassification.SMART_MODEL,
        system_prompt_template=DEFAULT_SYSTEM_PROMPT_TEMPLATE,
        system_info=DEFAULT_SYSTEM_INFO,
        user_prompt_template=DEFAULT_USER_PROMPT_TEMPLATE,
        additional_ability_arguments=DEFAULT_ADDITIONAL_ABILITY_ARGUMENTS,
    )

    def __init__(
        self,
        model_classification: LanguageModelClassification,
        system_prompt_template: str,
        system_info: list[str],
        user_prompt_template: str,
        additional_ability_arguments: dict,
    ):
        self._model_classification = model_classification
        self._system_prompt_template = system_prompt_template
        self._system_info = system_info
        self._user_prompt_template = user_prompt_template
        self._additional_ability_arguments = additional_ability_arguments

    @property
    def model_classification(self) -> LanguageModelClassification:
        return self._model_classification

    def build_prompt(
        self,
        task: Task,
        ability_schema: list[dict],
        os_info: str,
        api_budget: float,
        current_time: str,
        **kwargs,
    ) -> LanguageModelPrompt:
        template_kwargs = {
            "os_info": os_info,
            "api_budget": api_budget,
            "current_time": current_time,
            **kwargs,
        }

        for ability in ability_schema:
            ability["parameters"]["properties"].update(
                self._additional_ability_arguments
            )
            ability["parameters"]["required"] += list(
                self._additional_ability_arguments.keys()
            )

        template_kwargs["task_objective"] = task.objective
        template_kwargs["cycle_count"] = task.context.cycle_count
        template_kwargs["action_history"] = to_numbered_list(
            [action.summary() for action in task.context.prior_actions],
            no_items_response="Вы еще не предприняли никаких действий.",
            **template_kwargs,
        )
        template_kwargs["additional_info"] = to_numbered_list(
            [memory.summary() for memory in task.context.memories]
            + [info for info in task.context.supplementary_info],
            no_items_response="В настоящее время нет дополнительной информации.",
            **template_kwargs,
        )
        template_kwargs["user_input"] = to_numbered_list(
            [user_input for user_input in task.context.user_input],
            no_items_response="В настоящее время нет дополнительных соображений.",
            **template_kwargs,
        )
        template_kwargs["acceptance_criteria"] = to_numbered_list(
            [acceptance_criteria for acceptance_criteria in task.acceptance_criteria],
            **template_kwargs,
        )

        template_kwargs["system_info"] = to_numbered_list(
            self._system_info,
            **template_kwargs,
        )

        system_prompt = LanguageModelMessage(
            role=MessageRole.SYSTEM,
            content=self._system_prompt_template.format(**template_kwargs),
        )
        user_prompt = LanguageModelMessage(
            role=MessageRole.USER,
            content=self._user_prompt_template.format(**template_kwargs),
        )
        functions = [
            LanguageModelFunction(json_schema=ability) for ability in ability_schema
        ]

        return LanguageModelPrompt(
            messages=[system_prompt, user_prompt],
            functions=functions,
            # TODO:
            tokens_used=0,
        )

    def parse_response_content(
        self,
        response_content: dict,
    ) -> dict:
        """Parse the actual text response from the objective model.

        Args:
            response_content: The raw response content from the objective model.

        Returns:
            The parsed response.

        """
        function_name = response_content["function_call"]["name"]
        function_arguments = json_loads(response_content["function_call"]["arguments"])
        parsed_response = {
            "motivation": function_arguments.pop("motivation"),
            "self_criticism": function_arguments.pop("self_criticism"),
            "reasoning": function_arguments.pop("reasoning"),
            "next_ability": function_name,
            "ability_arguments": function_arguments,
        }
        return parsed_response
