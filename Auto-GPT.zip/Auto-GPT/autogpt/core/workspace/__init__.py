"""Рабочая область является центральным узлом для ресурсов агента на диске."""
from autogpt.core.workspace.base import Workspace
from autogpt.core.workspace.simple import SimpleWorkspace, WorkspaceSettings
