from typing import Any

from pydantic import BaseModel


class PluginConfig(BaseModel):
    """Класс для хранения конфигурации одного плагина"""

    name: str
    enabled: bool = False
    config: dict[str, Any] = None
