"""Основной скрипт для пакета autogpt."""
from pathlib import Path
from typing import Optional

import click


@click.group(invoke_without_command=True)
@click.option("-c", "--continuous", is_flag=True, help="Включить непрерывный режим")
@click.option(
    "--skip-reprompt",
    "-y",
    is_flag=True,
    help="Пропускает сообщения с повторными подсказками в начале скрипта",
)
@click.option(
    "--ai-settings",
    "-C",
    help=(
        "Указывает, какой файл ai_settings.yaml использовать относительно корневого каталога Auto-GPT."
        "Также автоматически пропустит повторную подсказку."
    ),
)
@click.option(
    "--prompt-settings",
    "-P",
    help="Указывает, какой файл prompt_settings.yaml использовать..",
)
@click.option(
    "-l",
    "--continuous-limit",
    type=int,
    help="Определяет количество запусков в непрерывном режиме.",
)
@click.option("--speak", is_flag=True, help="Включить Голосовой Режим")
@click.option("--debug", is_flag=True, help="Включить Режим Отладки")
@click.option("--gpt3only", is_flag=True, help="Включить Режим Только GPT3.5")
@click.option("--gpt4only", is_flag=True, help="Включить Режим Только GPT4")
@click.option(
    "--use-memory",
    "-m",
    "memory_type",
    type=str,
    help="Определяет, какой бэкэнд памяти использовать.",
)
@click.option(
    "-b",
    "--browser-name",
    help="Указывает, какой веб-браузер использовать при использовании селена для веб-скрейпинга Интернета.",
)
@click.option(
    "--allow-downloads",
    is_flag=True,
    help="Опасно: позволяет Auto-GPT загружать файлы изначально.",
)
@click.option(
    "--skip-news",
    is_flag=True,
    help="Указывает, подавлять ли вывод последних новостей при запуске.",
)
@click.option(
    # TODO: это пока скрытая опция, необходимая для интеграционного тестирования.
    #   Мы должны сделать это общедоступным, когда будем готовы развернуть
    #   рабочие пространства для конкретных агентов.
    "--workspace-directory",
    "-w",
    type=click.Path(),
    hidden=True,
)
@click.option(
    "--install-plugin-deps",
    is_flag=True,
    help="Устанавливает внешние зависимости для сторонних плагинов.",
)
@click.option(
    "--ai-name",
    type=str,
    help="Переопределение имени AI",
)
@click.option(
    "--ai-role",
    type=str,
    help="Переопределение роли AI",
)
@click.option(
    "--ai-goal",
    type=str,
    multiple=True,
    help="переопределение цели AI; может использоваться несколько раз для прохождения нескольких целей",
)
@click.pass_context
def main(
    ctx: click.Context,
    continuous: bool,
    continuous_limit: int,
    ai_settings: str,
    prompt_settings: str,
    skip_reprompt: bool,
    speak: bool,
    debug: bool,
    gpt3only: bool,
    gpt4only: bool,
    memory_type: str,
    browser_name: str,
    allow_downloads: bool,
    skip_news: bool,
    workspace_directory: str,
    install_plugin_deps: bool,
    ai_name: Optional[str],
    ai_role: Optional[str],
    ai_goal: tuple[str],
) -> None:
    """
    Добро пожаловать в AutoGPT — экспериментальное приложение с открытым исходным кодом, демонстрирующее возможности GPT-4, расширяющие границы AI.

    Запустите помощник Auto-GPT.
    """
    # Поместите импорт внутри функции, чтобы избежать импорта всего при запуске CLI.
    from autogpt.app.main import run_auto_gpt

    if ctx.invoked_subcommand is None:
        run_auto_gpt(
            continuous=continuous,
            continuous_limit=continuous_limit,
            ai_settings=ai_settings,
            prompt_settings=prompt_settings,
            skip_reprompt=skip_reprompt,
            speak=speak,
            debug=debug,
            gpt3only=gpt3only,
            gpt4only=gpt4only,
            memory_type=memory_type,
            browser_name=browser_name,
            allow_downloads=allow_downloads,
            skip_news=skip_news,
            working_directory=Path(
                __file__
            ).parent.parent.parent,  # TODO: сделайте это опцией
            workspace_directory=workspace_directory,
            install_plugin_deps=install_plugin_deps,
            ai_name=ai_name,
            ai_role=ai_role,
            ai_goals=ai_goal,
        )


if __name__ == "__main__":
    main()
