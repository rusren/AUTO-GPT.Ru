import abc
import enum
from typing import TYPE_CHECKING, Type

from pydantic import BaseModel

from autogpt.core.configuration import SystemConfiguration, UserConfigurable

if TYPE_CHECKING:
    from autogpt.core.ability import Ability, AbilityRegistry
    from autogpt.core.memory import Memory
    from autogpt.core.resource.model_providers import (
        EmbeddingModelProvider,
        LanguageModelProvider,
    )

    # Расширение до других типов по мере необходимости
    PluginType = (
        Type[Ability]  # Замена сейчас
        | Type[AbilityRegistry]  # Обмен, возможно, никогда
        | Type[LanguageModelProvider]  # Замена в ближайшее время
        | Type[EmbeddingModelProvider]  # Замена в ближайшее время
        | Type[Memory]  # Замена сейчас
        #    | Type[Planner]  # Замена в ближайшее время
    )


class PluginStorageFormat(str, enum.Enum):
    """Поддерживаемые форматы хранения плагинов.

    Плагины можно хранить в одном из этих поддерживаемых мест..

    """

    INSTALLED_PACKAGE = "installed_package"  # Требуется сейчас, загружает системные настройки по умолчанию
    WORKSPACE = "workspace"  # Required now
    # OPENAPI_URL = "open_api_url"           # Скоро (требуются инструменты, которых у нас пока нет).
    # OTHER_FILE_PATH = "other_file_path"    # Может быть, позже (может быть, сейчас)
    # GIT = "git"                            # Может позже (или скоро)
    # PYPI = "pypi"                          # Может позже
    # AUTOGPT_PLUGIN_SERVICE = "autogpt_plugin_service"  # Долгосрочное решение, требует проектирования
    # AUTO = "auto"                          # Функция на потом, может быть, автоматически найти плагин.


# Пример установленного пакета
# PluginLocation(
#     storage_format='installed_package',
#     storage_route='autogpt_plugins.twitter.SendTwitterMessage'
# )
# Пример рабочей области
# PluginLocation(
#     storage_format='workspace',
#     storage_route='relative/path/to/plugin.pkl'
#     OR
#     storage_route='relative/path/to/plugin.py'
# )
# Git
# PluginLocation(
#     storage_format='git',
#     Exact format TBD.
#     storage_route='https://github.com/gravelBridge/AutoGPT-WolframAlpha/blob/main/autogpt-wolframalpha/wolfram_alpha.py'
# )
# PyPI
# PluginLocation(
#     storage_format='pypi',
#     storage_route='package_name'
# )


# PluginLocation(
#     storage_format='installed_package',
#     storage_route='autogpt_plugins.twitter.SendTwitterMessage'
# )


# Путь хранения плагина.
#
# Это строка, указывающая, откуда загружать плагин (например, путь импорта или путь к файлу).
PluginStorageRoute = str


class PluginLocation(SystemConfiguration):
    """Расположение плагина.

    Это комбинация формата хранения плагинов и маршрута хранения плагинов.
    Он используется PluginService для загрузки плагинов.

    """

    storage_format: PluginStorageFormat = UserConfigurable()
    storage_route: PluginStorageRoute = UserConfigurable()


class PluginMetadata(BaseModel):
    """Метаданные о плагине."""

    name: str
    description: str
    location: PluginLocation


class PluginService(abc.ABC):
    """Базовый класс для службы плагинов.

    Служба плагина должна быть без гражданства.
    Это определяет интерфейс для загрузки плагинов из различных форматов хранения..

    """

    @staticmethod
    @abc.abstractmethod
    def get_plugin(plugin_location: PluginLocation) -> "PluginType":
        """Получить плагин из расположения плагинов."""
        ...

    ####################################
    # Загрузчики низкоуровневых форматов хранения #
    ####################################
    @staticmethod
    @abc.abstractmethod
    def load_from_file_path(plugin_route: PluginStorageRoute) -> "PluginType":
        """Загрузить плагин из пути к файлу."""

        ...

    @staticmethod
    @abc.abstractmethod
    def load_from_import_path(plugin_route: PluginStorageRoute) -> "PluginType":
        """Загрузите плагин из пути импорта."""
        ...

    @staticmethod
    @abc.abstractmethod
    def resolve_name_to_path(
        plugin_route: PluginStorageRoute, path_type: str
    ) -> PluginStorageRoute:
        """Преобразовать имя плагина в путь плагина."""
        ...

    #####################################
    # Загрузчики форматов хранения высокого уровня #
    #####################################

    @staticmethod
    @abc.abstractmethod
    def load_from_workspace(plugin_route: PluginStorageRoute) -> "PluginType":
        """Загрузить плагин из рабочей области."""
        ...

    @staticmethod
    @abc.abstractmethod
    def load_from_installed_package(plugin_route: PluginStorageRoute) -> "PluginType":
        """Загрузить плагин из установленного пакета."""
        ...
