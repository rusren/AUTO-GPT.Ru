from importlib import import_module
from typing import TYPE_CHECKING

from autogpt.core.plugin.base import (
    PluginLocation,
    PluginService,
    PluginStorageFormat,
    PluginStorageRoute,
)

if TYPE_CHECKING:
    from autogpt.core.plugin.base import PluginType


class SimplePluginService(PluginService):
    @staticmethod
    def get_plugin(plugin_location: dict | PluginLocation) -> "PluginType":
        """Получить плагин из расположения плагинов."""
        if isinstance(plugin_location, dict):
            plugin_location = PluginLocation.parse_obj(plugin_location)
        if plugin_location.storage_format == PluginStorageFormat.WORKSPACE:
            return SimplePluginService.load_from_workspace(
                plugin_location.storage_route
            )
        elif plugin_location.storage_format == PluginStorageFormat.INSTALLED_PACKAGE:
            return SimplePluginService.load_from_installed_package(
                plugin_location.storage_route
            )
        else:
            raise NotImplementedError(
                f"Формат хранения плагинов {plugin_location.storage_format} не реализован."
            )

    ####################################
    # Загрузчики низкоуровневых форматов хранения #
    ####################################
    @staticmethod
    def load_from_file_path(plugin_route: PluginStorageRoute) -> "PluginType":
        """Загрузить плагин из пути к файлу."""
        # TODO: Определите формат хранения на диске и реализуйте его.
        #   Можно извлечь из существующей реализации загрузки zip-файла
        raise NotImplemented("Загрузка из пути к файлу не реализована.")

    @staticmethod
    def load_from_import_path(plugin_route: PluginStorageRoute) -> "PluginType":
        """Загрузите плагин из пути импорта."""
        module_path, _, class_name = plugin_route.rpartition(".")
        return getattr(import_module(module_path), class_name)

    @staticmethod
    def resolve_name_to_path(
        plugin_route: PluginStorageRoute, path_type: str
    ) -> PluginStorageRoute:
        """Преобразовать имя плагина в путь плагина."""
        # TODO: Реализуйте систему обнаружения для поиска плагинов по имени из известных мест хранения.
        #  Например. если мы знаем, что path_type — это путь к файлу, мы можем найти его в workspace.
        #  Если это путь импорта, мы можем проверить основную систему и пакет auto_gpt_plugins.
        raise NotImplemented("Преобразование имени плагина в путь не реализовано.")

    #####################################
    # Загрузчики форматов хранения высокого уровня #
    #####################################

    @staticmethod
    def load_from_workspace(plugin_route: PluginStorageRoute) -> "PluginType":
        """Загрузить плагин из workspace."""
        plugin = SimplePluginService.load_from_file_path(plugin_route)
        return plugin

    @staticmethod
    def load_from_installed_package(plugin_route: PluginStorageRoute) -> "PluginType":
        plugin = SimplePluginService.load_from_import_path(plugin_route)
        return plugin
