import abc

from autogpt.core.configuration import SystemConfiguration
from autogpt.core.planning.schema import (
    LanguageModelClassification,
    LanguageModelPrompt,
)

# class Planner(abc.ABC):
#     """Управляет планированием и постановкой целей агента, создавая подсказки языковой модели."""
#
#     @staticmethod
#     @abc.abstractmethod
#     async def decide_name_and_goals(
#         user_objective: str,
#     ) -> LanguageModelResponse:
#         """Определите имя и цели агента из определенной пользователем цели.
#
#         Args:
#             user_objective: Пользовательская цель для агента.
#
#         Returns:
#             Имя агента и цели как ответ от языковой модели.
#
#         """
#         ...
#
#     @abc.abstractmethod
#     async def plan(self, context: PlanningContext) -> LanguageModelResponse:
#         """Запланируйте следующую способность для агента.
#
#         Args:
#             context: Объект контекста, содержащий информацию о прогрессе агента,
#             результатах, воспоминаниях и отзывах.
#
#
#         Returns:
#             Следующая способность, которой агент должен овладеть наряду с мыслями и рассуждениями.
#
#         """
#         ...
#
#     @abc.abstractmethod
#     def reflect(
#         self,
#         context: ReflectionContext,
#     ) -> LanguageModelResponse:
#         """Проанализируйте запланированную способность и проявите самокритику.
#
#
#         Args:
#             context: Контекстный объект, содержащий информацию о
#                      рассуждениях, плане, мыслях и критике агента.
#
#         Returns:
#             Самокритика по поводу плана агента.
#
#         """
#         ...


class PromptStrategy(abc.ABC):
    default_configuration: SystemConfiguration

    @property
    @abc.abstractmethod
    def model_classification(self) -> LanguageModelClassification:
        ...

    @abc.abstractmethod
    def build_prompt(self, *_, **kwargs) -> LanguageModelPrompt:
        ...

    @abc.abstractmethod
    def parse_response_content(self, response_content: dict) -> dict:
        ...
