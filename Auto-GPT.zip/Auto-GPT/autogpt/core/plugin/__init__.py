"""Система плагинов позволяет расширять Агент новыми функциями."""
from autogpt.core.plugin.base import PluginService
