"""Команды для выполнения кода"""

COMMAND_CATEGORY = "execute_code"
COMMAND_CATEGORY_TITLE = "Выполнить код"

import os
import subprocess
from pathlib import Path

import docker
from docker.errors import DockerException, ImageNotFound
from docker.models.containers import Container as DockerContainer

from autogpt.agents.agent import Agent
from autogpt.command_decorator import command
from autogpt.config import Config
from autogpt.logs import logger

from .decorators import sanitize_path_arg

ALLOWLIST_CONTROL = "allowlist"
DENYLIST_CONTROL = "denylist"


@command(
    "execute_python_code",
    "Создает файл Python и выполняет его",
    {
        "code": {
            "type": "string",
            "description": "Код Python для запуска",
            "required": True,
        },
        "name": {
            "type": "string",
            "description": "Имя, которое будет присвоено файлу python",
            "required": True,
        },
    },
)
def execute_python_code(code: str, name: str, agent: Agent) -> str:
    """Создайте и выполните файл Python в контейнере Docker и верните STDOUT исполняемого кода.
    Если есть какие-либо данные, которые необходимо зафиксировать, используйте оператор печати

    Args:
        code (str): The Python code to run
        name (str): A name to be given to the Python file

    Returns:
        str: The STDOUT captured from the code when it ran
    """
    ai_name = agent.ai_config.ai_name
    code_dir = agent.workspace.get_path(Path(ai_name, "executed_code"))
    os.makedirs(code_dir, exist_ok=True)

    if not name.endswith(".py"):
        name = name + ".py"

    # The `name` arg is not covered by @sanitize_path_arg,
    # so sanitization must be done here to prevent path traversal.
    file_path = agent.workspace.get_path(code_dir / name)
    if not file_path.is_relative_to(code_dir):
        return "Ошибка: 'name' аргумент привел к обходу пути, операция прервана"

    try:
        with open(file_path, "w+", encoding="utf-8") as f:
            f.write(code)

        return execute_python_file(str(file_path), agent)
    except Exception as e:
        return f"Ошибка: {str(e)}"


@command(
    "execute_python_file",
    "Выполняет существующий файл Python",
    {
        "filename": {
            "type": "string",
            "description": "Имя файла для выполнения",
            "required": True,
        },
    },
)
@sanitize_path_arg("filename")
def execute_python_file(filename: str, agent: Agent) -> str:
    """Выполнить файл Python в контейнере Docker и вернуть результат

    Args:
        filename (str): The name of the file to execute

    Returns:
        str: The output of the file
    """
    logger.info(
        f"Выполнение файла Python '{filename}' в рабочем директории '{agent.config.workspace_path}'"
    )

    if not filename.endswith(".py"):
        return "Ошибка: недопустимый тип файла. Разрешены только файлы .py"

    file_path = Path(filename)
    if not file_path.is_file():
        # Имитируйте ответ, который вы получаете из командной строки, чтобы его было легче идентифицировать
        return (
            f"python: не могу открыть файл '{filename}': [ОШИБКА 2] Данный файл или каталог отсутствует"
        )

    if we_are_running_in_a_docker_container():
        logger.debug(
            f"Auto-GPT работает в контейнере Docker; выполнение {file_path} непосредственно..."
        )
        result = subprocess.run(
            ["python", str(file_path)],
            capture_output=True,
            encoding="utf8",
            cwd=agent.config.workspace_path,
        )
        if result.returncode == 0:
            return result.stdout
        else:
            return f"Ошибка: {result.stderr}"

    logger.debug("Auto-GPT не работает в контейнере Docker")
    try:
        client = docker.from_env()
        # You can replace this with the desired Python image/version
        # You can find available Python images on Docker Hub:
        # https://hub.docker.com/_/python
        image_name = "python:3-alpine"
        try:
            client.images.get(image_name)
            logger.debug(f"Образ '{image_name}' найден локально")
        except ImageNotFound:
            logger.info(
                f"Образ '{image_name}' локально не найдено, взято из Docker Hub..."
            )
            # Используйте низкоуровневый API для потоковой передачи ответа на запрос запроса
            low_level_client = docker.APIClient()
            for line in low_level_client.pull(image_name, stream=True, decode=True):
                # Распечатать статус и прогресс, если они доступны
                status = line.get("состояние")
                progress = line.get("прогресс")
                if status and progress:
                    logger.info(f"{status}: {progress}")
                elif status:
                    logger.info(status)

        logger.debug(f"Запуск {file_path} в {image_name} контейнере...")
        container: DockerContainer = client.containers.run(
            image_name,
            [
                "python",
                file_path.relative_to(agent.workspace.root).as_posix(),
            ],
            volumes={
                str(agent.config.workspace_path): {
                    "bind": "/workspace",
                    "mode": "rw",
                }
            },
            working_dir="/workspace",
            stderr=True,
            stdout=True,
            detach=True,
        )  # type: ignore

        container.wait()
        logs = container.logs().decode("utf-8")
        container.remove()

        # print(f"Execution complete. Output: {output}")
        # print(f"Logs: {logs}")

        return logs

    except DockerException as e:
        logger.warn(
            "Не удалось запустить скрипт в контейнере. Установите Docker https://docs.docker.com/get-docker/"
        )
        return f"Ошибка: {str(e)}"

    except Exception as e:
        return f"Ошибка: {str(e)}"


def validate_command(command: str, config: Config) -> bool:
    """Подтвердите команду, чтобы убедиться, что она разрешена

    Args:
        command (str): Команда для проверки
        config (Config): Конфигурация для проверки команды

    Returns:
        bool: True, если команда разрешена, False если запрещена
    """
    if not command:
        return False

    command_name = command.split()[0]

    if config.shell_command_control == ALLOWLIST_CONTROL:
        return command_name in config.shell_allowlist
    else:
        return command_name not in config.shell_denylist


@command(
    "execute_shell",
    "Выполняет команду Shell, только неинтерактивные команды.",
    {
        "command_line": {
            "type": "string",
            "description": "Командная строка для выполнения",
            "required": True,
        }
    },
    enabled=lambda config: config.execute_local_commands,
    disabled_reason="Вам не разрешено запускать локальные SHELL команды. "
                    "Для выполнения команд оболочки для параметра EXECUTE_LOCAL_COMMANDS "
                    "должно быть установлено значение 'True' в вашем файле конфигурации: .env"
                    " — не пытайтесь обойти ограничение.",
)
def execute_shell(command_line: str, agent: Agent) -> str:
    """Выполнить команду оболочки и вернуть вывод

    Args:
        command_line (str): The command line to execute

    Returns:
        str: The output of the command
    """
    if not validate_command(command_line, agent.config):
        logger.info(f"Команда '{command_line}' не разрешена")
        return "Ошибка: эта команда оболочки не разрешена."

    current_dir = Path.cwd()
    # Change dir into workspace if necessary
    if not current_dir.is_relative_to(agent.config.workspace_path):
        os.chdir(agent.config.workspace_path)

    logger.info(
        f"Выполнение команды '{command_line}' в рабочем каталоге '{os.getcwd()}'"
    )

    result = subprocess.run(command_line, capture_output=True, shell=True)
    output = f"STDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"

    # Вернитесь к предыдущему рабочему каталогу

    os.chdir(current_dir)
    return output


@command(
    "execute_shell_popen",
    "Выполняет команду оболочки, только неинтерактивные команды",
    {
        "command_line": {
            "type": "string",
            "description": "Командная строка для выполнения",
            "required": True,
        }
    },
    lambda config: config.execute_local_commands,
    "Вам не разрешено запускать локальные команды оболочки. "
    "Чтобы выполнять команды оболочки, EXECUTE_LOCAL_COMMANDS "
    "должен быть установлен 'True' в вашей конфигурации. "
    "Не пытайтесь обойти ограничение.",
)
def execute_shell_popen(command_line, agent: Agent) -> str:
    """Выполнить команду оболочки с помощью Popen и вернуть описание события и идентификатор процесса на английском языке.

    Args:
        command_line (str): The command line to execute

    Returns:
        str: Description of the fact that the process started and its id
    """
    if not validate_command(command_line, agent.config):
        logger.info(f"Команда '{command_line}' не разрешена")
        return "Ошибка: эта команда оболочки не разрешена."

    current_dir = os.getcwd()
    # При необходимости измените каталог на workspace.
    if agent.config.workspace_path not in current_dir:
        os.chdir(agent.config.workspace_path)

    logger.info(
        f"Выполнение команды '{command_line}' в рабочем каталоге '{os.getcwd()}'"
    )

    do_not_show_output = subprocess.DEVNULL
    process = subprocess.Popen(
        command_line, shell=True, stdout=do_not_show_output, stderr=do_not_show_output
    )

    # Change back to whatever the prior working dir was

    os.chdir(current_dir)

    return f"Подпроцесс запущен с PID:'{str(process.pid)}'"


def we_are_running_in_a_docker_container() -> bool:
    """Проверяем, работаем ли мы в контейнере Docker

    Returns:
        bool: True if we are running in a Docker container, False otherwise
    """
    return os.path.exists("/.dockerenv")
