import logging


def get_client_logger():
    # Настройте ведение журнала, прежде чем мы сделаем что-либо еще.
    # Журналам приложений нужно место для жизни..
    client_logger = logging.getLogger("autogpt_client_application")
    client_logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(formatter)

    client_logger.addHandler(ch)

    return client_logger
