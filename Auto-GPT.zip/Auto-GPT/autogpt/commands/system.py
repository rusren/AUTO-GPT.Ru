"""Команды для управления внутренним состоянием программы"""

from __future__ import annotations

COMMAND_CATEGORY = "system"
COMMAND_CATEGORY_TITLE = "System"

from typing import NoReturn

from autogpt.agents.agent import Agent
from autogpt.command_decorator import command
from autogpt.logs import logger


@command(
    "goals_accomplished",
    "Цели достигнуты, делать нечего",
    {
        "reason": {
            "type": "string",
            "description": "Краткое изложение для пользователя того, как цели были достигнуты",
            "required": True,
        }
    },
)
def task_complete(reason: str, agent: Agent) -> NoReturn:
    """
    Функция, которая принимает строку и выходит из программы

    Parameters:
        reason (str): A summary to the user of how the goals were accomplished.
    Returns:
        A result string from create chat completion. A list of suggestions to
            improve the code.
    """
    logger.info(title="Завершение работы...\n", message=reason)
    quit()
