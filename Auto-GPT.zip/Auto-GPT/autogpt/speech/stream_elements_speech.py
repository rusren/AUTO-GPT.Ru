import logging
import os

import requests
from playsound import playsound

from autogpt.config import Config
from autogpt.speech.base import VoiceBase


class StreamElementsSpeech(VoiceBase):
    """Речевой модуль Streamelements для autogpt"""

    def _setup(self, config: Config) -> None:
        """Настройте голоса, ключ API и т.д."""

    def _speech(self, text: str, voice: str, _: int = 0) -> bool:
        """Произносить текст с помощью API streamelements

        Args:
            text (str): The text to speak
            voice (str): The voice to use

        Returns:
            bool: True, если запрос был успешным, False в противном случае
        """
        tts_url = (
            f"https://api.streamelements.com/kappa/v2/speech?voice={voice}&text={text}"
        )
        response = requests.get(tts_url)

        if response.status_code == 200:
            with open("speech.mp3", "wb") as f:
                f.write(response.content)
            playsound("speech.mp3")
            os.remove("speech.mp3")
            return True
        else:
            logging.error(
                "Запрос не выполнен с кодом состояния: %s, содержание ответа: %s",
                response.status_code,
                response.content,
            )
            return False
