import logging

from autogpt.core.ability.base import Ability, AbilityConfiguration
from autogpt.core.ability.schema import AbilityResult
from autogpt.core.plugin.simple import PluginLocation, PluginStorageFormat


class CreateNewAbility(Ability):
    default_configuration = AbilityConfiguration(
        location=PluginLocation(
            storage_format=PluginStorageFormat.INSTALLED_PACKAGE,
            storage_route="autogpt.core.ability.builtins.CreateNewAbility",
        ),
    )

    def __init__(
        self,
        logger: logging.Logger,
        configuration: AbilityConfiguration,
    ):
        self._logger = logger
        self._configuration = configuration

    @classmethod
    def description(cls) -> str:
        return "Создайте новую способность, написав код на Python."

    @classmethod
    def arguments(cls) -> dict:
        return {
            "ability_name": {
                "type": "string",
                "description": "Значимое и лаконичное название для новой способности.",
            },
            "description": {
                "type": "string",
                "description": "Подробное описание способности и ее использования, включая любые ограничения.",
            },
            "arguments": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "Имя аргумента.",
                        },
                        "type": {
                            "type": "string",
                            "description": "Тип аргумента. Должен быть стандартный тип схемы json.",
                        },
                        "description": {
                            "type": "string",
                            "description": "Подробное описание аргумента и его использования.",
                        },
                    },
                },
                "description": "Список аргументов, которые примет способность.",
            },
            "required_arguments": {
                "type": "array",
                "items": {
                    "type": "string",
                    "description": "Имена аргументов, которые требуются.",
                },
                "description": "Список имен аргументов, которые требуются.",
            },
            "package_requirements": {
                "type": "array",
                "items": {
                    "type": "string",
                    "description": "Пакет Python, необходимый для выполнения возможности.",
                },
                "description": "Список имен пакетов Python, необходимых для выполнения возможности.",
            },
            "code": {
                "type": "string",
                "description": "Код Python, который будет выполняться при вызове способности.",
            },
        }

    @classmethod
    def required_arguments(cls) -> list[str]:
        return [
            "ability_name",
            "description",
            "arguments",
            "required_arguments",
            "package_requirements",
            "code",
        ]

    async def __call__(
        self,
        ability_name: str,
        description: str,
        arguments: list[dict],
        required_arguments: list[str],
        package_requirements: list[str],
        code: str,
    ) -> AbilityResult:
        raise NotImplementedError
