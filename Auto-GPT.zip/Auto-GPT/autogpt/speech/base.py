"""Базовый класс для всех голосовых классов."""
from __future__ import annotations

import abc
import re
from threading import Lock
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from autogpt.config import Config

from autogpt.singleton import AbstractSingleton


class VoiceBase(AbstractSingleton):
    """
    Базовый класс для всех голосовых классов.
    """

    def __init__(self, config: Config):
        """
        Инициализировать голосовой класс.
        """
        self._url = None
        self._headers = None
        self._api_key = None
        self._voices = []
        self._mutex = Lock()
        self._setup(config)

    def say(self, text: str, voice_index: int = 0) -> bool:
        """
        Произнесите заданный текст.

        Args:
            text (str): Текст, который нужно сказать.
            voice_index (int): Индекс голоса для использования.
        """
        text = re.sub(
            r"\b(?:https?://[-\w_.]+/?\w[-\w_.]*\.(?:[-\w_.]+/?\w[-\w_.]*\.)?[a-z]+(?:/[-\w_.%]+)*\b(?!\.))",
            "",
            text,
        )
        with self._mutex:
            return self._speech(text, voice_index)

    @abc.abstractmethod
    def _setup(self, config: Config) -> None:
        """
        Настройте голоса, ключ API и т.д.
        """

    @abc.abstractmethod
    def _speech(self, text: str, voice_index: int = 0) -> bool:
        """
        Воспроизведите заданный текст.

        Args:
            text (str): Текст для воспроизведения.
        """
