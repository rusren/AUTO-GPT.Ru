from __future__ import annotations

import json
import time
from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from autogpt.config import AIConfig, Config
    from autogpt.llm.base import ChatModelResponse, ChatSequence
    from autogpt.memory.vector import VectorMemory
    from autogpt.models.command_registry import CommandRegistry

from autogpt.json_utils.utilities import extract_dict_from_response, validate_dict
from autogpt.llm.api_manager import ApiManager
from autogpt.llm.base import Message
from autogpt.llm.utils import count_string_tokens
from autogpt.logs import logger
from autogpt.logs.log_cycle import (
    CURRENT_CONTEXT_FILE_NAME,
    FULL_MESSAGE_HISTORY_FILE_NAME,
    NEXT_ACTION_FILE_NAME,
    USER_INPUT_FILE_NAME,
    LogCycleHandler,
)
from autogpt.workspace import Workspace

from .base import AgentThoughts, BaseAgent, CommandArgs, CommandName


class Agent(BaseAgent):
    """Класс агента для взаимодействия с Auto-GPT."""

    def __init__(
        self,
        ai_config: AIConfig,
        command_registry: CommandRegistry,
        memory: VectorMemory,
        triggering_prompt: str,
        config: Config,
        cycle_budget: Optional[int] = None,
    ):
        super().__init__(
            ai_config=ai_config,
            command_registry=command_registry,
            config=config,
            default_cycle_instruction=triggering_prompt,
            cycle_budget=cycle_budget,
        )

        self.memory = memory
        """VectorMemoryProvider, используемый для управления контекстом агента (TODO)"""

        self.workspace = Workspace(config.workspace_path, config.restrict_to_workspace)
        """Workspace, к которой у агента есть доступ, например. для чтения/записи файлов."""

        self.created_at = datetime.now().strftime("%Y%m%d_%H%M%S")
        """Отметка времени создания агента; используется только для структурированного ведения журнала отладки."""

        self.log_cycle_handler = LogCycleHandler()
        """LogCycleHandler для структурированного ведения журнала отладки."""

    def construct_base_prompt(self, *args, **kwargs) -> ChatSequence:
        if kwargs.get("prepend_messages") is None:
            kwargs["prepend_messages"] = []

        # Clock
        kwargs["prepend_messages"].append(
            Message("system", f"Текущее время и дата {time.strftime('%c')}"),
        )

        # Добавьте информацию о бюджете (if any) to prompt
        api_manager = ApiManager()
        if api_manager.get_total_budget() > 0.0:
            remaining_budget = (
                api_manager.get_total_budget() - api_manager.get_total_cost()
            )
            if remaining_budget < 0:
                remaining_budget = 0

            budget_msg = Message(
                "system",
                f"Ваш оставшийся бюджет API составляет ${remaining_budget:.3f}"
                + (
                    " БЮДЖЕТ ПРЕВЫШЕН! ВЫКЛЮЧАЮСЬ!\n\n"
                    if remaining_budget == 0
                    else " Бюджет почти превышен! Завершите работу!\n\n"
                    if remaining_budget < 0.005
                    else " Бюджет почти превышен. Завершить.\n\n"
                    if remaining_budget < 0.01
                    else ""
                ),
            )
            logger.debug(budget_msg)

            if kwargs.get("append_messages") is None:
                kwargs["append_messages"] = []
            kwargs["append_messages"].append(budget_msg)

        return super().construct_base_prompt(*args, **kwargs)

    def on_before_think(self, *args, **kwargs) -> ChatSequence:
        prompt = super().on_before_think(*args, **kwargs)

        self.log_cycle_handler.log_count_within_cycle = 0
        self.log_cycle_handler.log_cycle(
            self.ai_config.ai_name,
            self.created_at,
            self.cycle_count,
            self.history.raw(),
            FULL_MESSAGE_HISTORY_FILE_NAME,
        )
        self.log_cycle_handler.log_cycle(
            self.ai_config.ai_name,
            self.created_at,
            self.cycle_count,
            prompt.raw(),
            CURRENT_CONTEXT_FILE_NAME,
        )
        return prompt

    def execute(
        self,
        command_name: str | None,
        command_args: dict[str, str] | None,
        user_input: str | None,
    ) -> str:
        # Execute command
        if command_name is not None and command_name.lower().startswith("ошибка"):
            result = f"Не удалось выполнить команду: {command_name}{command_args}"
        elif command_name == "human_feedback":
            result = f"Обратная связь: {user_input}"
            self.log_cycle_handler.log_cycle(
                self.ai_config.ai_name,
                self.created_at,
                self.cycle_count,
                user_input,
                USER_INPUT_FILE_NAME,
            )

        else:
            for plugin in self.config.plugins:
                if not plugin.can_handle_pre_command():
                    continue
                command_name, arguments = plugin.pre_command(command_name, command_args)
            command_result = execute_command(
                command_name=command_name,
                arguments=command_args,
                agent=self,
            )
            result = f"Команда {command_name} возвращена: " f"{command_result}"

            result_tlength = count_string_tokens(str(command_result), self.llm.name)
            memory_tlength = count_string_tokens(
                str(self.history.summary_message()), self.llm.name
            )
            if result_tlength + memory_tlength > self.send_token_limit:
                result = f"Отказ: команда {command_name} вернула слишком много вывода. \
                    Не выполняйте эту команду снова с теми же аргументами."

            for plugin in self.config.plugins:
                if not plugin.can_handle_post_command():
                    continue
                result = plugin.post_command(command_name, result)
        # Check if there's a result from the command append it to the message
        if result is None:
            self.history.add("system", "Невозможно выполнить команду", "action_result")
        else:
            self.history.add("system", result, "action_result")

        return result

    def parse_and_process_response(
        self, llm_response: ChatModelResponse, *args, **kwargs
    ) -> tuple[CommandName | None, CommandArgs | None, AgentThoughts]:
        if not llm_response.content:
            raise SyntaxError("Ответ помощника не содержит текста")

        assistant_reply_dict = extract_dict_from_response(llm_response.content)

        valid, errors = validate_dict(assistant_reply_dict, self.config)
        if not valid:
            raise SyntaxError(
                "Проверка ответа не удалась:\n  "
                + ";\n  ".join([str(e) for e in errors])
            )

        for plugin in self.config.plugins:
            if not plugin.can_handle_post_planning():
                continue
            assistant_reply_dict = plugin.post_planning(assistant_reply_dict)

        response = None, None, assistant_reply_dict

        # Print Assistant thoughts
        if assistant_reply_dict != {}:
            # Получить имя команды и аргументы
            try:
                command_name, arguments = extract_command(
                    assistant_reply_dict, llm_response, self.config
                )
                response = command_name, arguments, assistant_reply_dict
            except Exception as e:
                logger.error("Ошибка: \n", str(e))

        self.log_cycle_handler.log_cycle(
            self.ai_config.ai_name,
            self.created_at,
            self.cycle_count,
            assistant_reply_dict,
            NEXT_ACTION_FILE_NAME,
        )
        return response


def extract_command(
    assistant_reply_json: dict, assistant_reply: ChatModelResponse, config: Config
) -> tuple[str, dict[str, str]]:
    """Разобрать ответ и вернуть имя команды и аргументы

    Args:
        assistant_reply_json (dict): Объект ответа от AI
        assistant_reply (ChatModelResponse): Реакция AI от модели
        config (Config): Объект конфигурации

    Returns:
        tuple: The command name and arguments

    Raises:
        json.decoder.JSONDecodeError: If the response is not valid JSON

        Exception: If any other error occurs
    """
    if config.openai_functions:
        if assistant_reply.function_call is None:
            return "Ошибка:", {"message": "Нет 'function_call' в ответе помощника"}
        assistant_reply_json["command"] = {
            "name": assistant_reply.function_call.name,
            "args": json.loads(assistant_reply.function_call.arguments),
        }
    try:
        if "command" not in assistant_reply_json:
            return "Ошибка:", {"message": "Отсутствует 'command' объект в JSON"}

        if not isinstance(assistant_reply_json, dict):
            return (
                "Ошибка:",
                {
                    "message": f"Предыдущее отправленное сообщение не было словарем {assistant_reply_json}"
                },
            )

        command = assistant_reply_json["command"]
        if not isinstance(command, dict):
            return "Ошибка:", {"message": "'command' объект не словарь"}

        if "name" not in command:
            return "Ошибка:", {"message": "Отсутствует поле 'name' в объекте  'command'"}

        command_name = command["name"]

        # Use an empty dictionary if 'args' field is not present in 'command' object
        arguments = command.get("args", {})

        return command_name, arguments
    except json.decoder.JSONDecodeError:
        return "Ошибка:", {"message": "Неверный JSON"}
    # All other errors, return "Error: + error message"
    except Exception as e:
        return "Ошибка:", {"message": str(e)}


def execute_command(
    command_name: str,
    arguments: dict[str, str],
    agent: Agent,
) -> Any:
    """Execute the command and return the result

    Args:
        command_name (str): The name of the command to execute
        arguments (dict): The arguments for the command
        agent (Agent): The agent that is executing the command

    Returns:
        str: The result of the command
    """
    try:
        # Выполнить нативную команду с тем же именем или псевдонимом, если он существует
        if command := agent.command_registry.get_command(command_name):
            return command(**arguments, agent=agent)

        # Обработка чужих команд (например, из плагинов)
        for command in agent.ai_config.prompt_generator.commands:
            if (
                command_name == command.label.lower()
                or command_name == command.name.lower()
            ):
                return command.function(**arguments)

        raise RuntimeError(
            f"Невозможно выполнить '{command_name}': неизвестная команда."
            " Не пытайтесь использовать эту команду снова."
        )
    except Exception as e:
        return f"Ошибка: {str(e)}"
