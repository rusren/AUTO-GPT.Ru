"""Auto-GPT: AI-помощник на базе GPT"""
import autogpt.app.cli

if __name__ == "__main__":
    autogpt.app.cli.main()
