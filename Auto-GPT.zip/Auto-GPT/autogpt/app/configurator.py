"""Конфигуратор модуля."""
from __future__ import annotations

from typing import Literal

import click
from colorama import Back, Fore, Style

from autogpt import utils
from autogpt.config import Config
from autogpt.config.config import GPT_3_MODEL, GPT_4_MODEL
from autogpt.llm.api_manager import ApiManager
from autogpt.logs import logger
from autogpt.memory.vector import get_supported_memory_backends


def create_config(
    config: Config,
    continuous: bool,
    continuous_limit: int,
    ai_settings_file: str,
    prompt_settings_file: str,
    skip_reprompt: bool,
    speak: bool,
    debug: bool,
    gpt3only: bool,
    gpt4only: bool,
    memory_type: str,
    browser_name: str,
    allow_downloads: bool,
    skip_news: bool,
) -> None:
    """Обновляет объект конфигурации с заданными аргументами.

    Args:
        continuous (bool): следует ли работать в непрерывном режиме
        continuous_limit (int): количество запусков в непрерывном режиме
        ai_settings_file (str): путь к файлу ai_settings.yaml
        prompt_settings_file (str): путь к файлу prompt_settings.yaml
        skip_reprompt (bool): следует ли пропускать сообщения с повторными подсказками в начале скрипта
        speak (bool): включить режим разговора
        debug (bool): Включить режим отладки
        gpt3only (bool): включить режим ,только GPT3.5
        gpt4only (bool): включить ли режим, только GPT4
        memory_type (str): тип используемой внутренней памяти
        browser_name (str): имя браузера, используемого при использовании веб-скрейпинга Интернета
        allow_downloads (bool): разрешить Auto-GPT загружать файлы
        skips_news (bool): подавлять вывод последних новостей при запуске
    """
    config.debug_mode = False
    config.continuous_mode = False
    config.speak_mode = False

    if debug:
        logger.typewriter_log("Режим отладки: ", Fore.GREEN, "ВКЛЮЧЕНО")
        config.debug_mode = True

    if continuous:
        logger.typewriter_log("Непрерывный режим: ", Fore.RED, "ВКЛЮЧЕНО")
        logger.typewriter_log(
            "ПРЕДУПРЕЖДЕНИЕ: ",
            Fore.RED,
            "Непрерывный режим не рекомендуется. Это потенциально опасно"
            " и может привести к тому, что ваш ИИ будет работать вечно или "
            "выполнять действия, которые вы обычно не разрешаете. Используйте на свой риск.",
        )
        config.continuous_mode = True

        if continuous_limit:
            logger.typewriter_log(
                "Непрерывный Лимит: ", Fore.GREEN, f"{continuous_limit}"
            )
            config.continuous_limit = continuous_limit

    # Проверьте, используется ли непрерывный предел без непрерывного режима
    if continuous_limit and not continuous:
        raise click.UsageError("--continuous-лимит можно использовать только с --continuous")

    if speak:
        logger.typewriter_log("Голосовой режим: ", Fore.GREEN, "ВКЛЮЧЕНО")
        config.speak_mode = True

    # Установить модели LLM по умолчанию
    if gpt3only:
        logger.typewriter_log("Только режим GPT3.5: ", Fore.GREEN, "ВКЛЮЧЕНО")
        # --gpt3only всегда должен использовать gpt-3.5-turbo, несмотря на пользовательскую конфигурацию FAST_LLM.
        config.fast_llm = GPT_3_MODEL
        config.smart_llm = GPT_3_MODEL
    elif (
        gpt4only
        and check_model(GPT_4_MODEL, model_type="smart_llm", config=config)
        == GPT_4_MODEL
    ):
        logger.typewriter_log("Только режим GPT4: ", Fore.GREEN, "ВКЛЮЧЕНО")
        # --gpt4only всегда должен использовать gpt-4, несмотря на конфигурацию пользователя SMART_LLM
        config.fast_llm = GPT_4_MODEL
        config.smart_llm = GPT_4_MODEL
    else:
        config.fast_llm = check_model(config.fast_llm, "fast_llm", config=config)
        config.smart_llm = check_model(config.smart_llm, "smart_llm", config=config)

    if memory_type:
        supported_memory = get_supported_memory_backends()
        chosen = memory_type
        if chosen not in supported_memory:
            logger.typewriter_log(
                "ПОДДЕРЖИВАЮТСЯ ТОЛЬКО СЛЕДУЮЩИЕ ОБЪЕМЫ ПАМЯТИ: ",
                Fore.RED,
                f"{supported_memory}",
            )
            logger.typewriter_log("По умолчанию: ", Fore.YELLOW, config.memory_backend)
        else:
            config.memory_backend = chosen

    if skip_reprompt:
        logger.typewriter_log("Пропустить повторный запрос: ", Fore.GREEN, "ВКЛЮЧЕНО")
        config.skip_reprompt = True

    if ai_settings_file:
        file = ai_settings_file

        # Validate file
        (validated, message) = utils.validate_yaml_file(file)
        if not validated:
            logger.typewriter_log("ОШИБКА ПРОВЕРКИ ФАЙЛА", Fore.RED, message)
            logger.double_check()
            exit(1)

        logger.typewriter_log("Использование файла настроек AI:", Fore.GREEN, file)
        config.ai_settings_file = file
        config.skip_reprompt = True

    if prompt_settings_file:
        file = prompt_settings_file

        # Validate file
        (validated, message) = utils.validate_yaml_file(file)
        if not validated:
            logger.typewriter_log("ОШИБКА ПРОВЕРКИ ФАЙЛА", Fore.RED, message)
            logger.double_check()
            exit(1)

        logger.typewriter_log("Использование файла параметров подсказки:", Fore.GREEN, file)
        config.prompt_settings_file = file

    if browser_name:
        config.selenium_web_browser = browser_name

    if allow_downloads:
        logger.typewriter_log("Нативное скачивание:", Fore.GREEN, "ВКЛЮЧЕНО")
        logger.typewriter_log(
            "ПРЕДУПРЕЖДЕНИЕ: ",
            Fore.YELLOW,
            f"{Back.LIGHTYELLOW_EX}Auto-GPT теперь сможет загружать и сохранять файлы на вашем компьютере.{Back.RESET} "
            + "Рекомендуется внимательно следить за любыми файлами, которые загружаются.",
        )
        logger.typewriter_log(
            "ПРЕДУПРЕЖДЕНИЕ: ",
            Fore.YELLOW,
            f"{Back.RED + Style.BRIGHT}ВСЕГДА ПОМНИТЕ НИКОГДА НЕ ОТКРЫВАТЬ ФАЙЛЫ, В КОТОРЫХ ВЫ НЕ УВЕРЕНЫ!{Style.RESET_ALL}",
        )
        config.allow_downloads = True

    if skip_news:
        config.skip_news = True


def check_model(
    model_name: str,
    model_type: Literal["smart_llm", "fast_llm"],
    config: Config,
) -> str:
    """Проверьте, доступна ли модель для использования. Если нет, верните gpt-3.5-turbo."""
    openai_credentials = config.get_openai_credentials(model_name)
    api_manager = ApiManager()
    models = api_manager.get_models(**openai_credentials)

    if any(model_name in m["id"] for m in models):
        return model_name

    logger.typewriter_log(
        "ПРЕДУПРЕЖДЕНИЕ: ",
        Fore.YELLOW,
        f"У вас нет доступа {model_name}. Настройка {model_type} на "
        f"gpt-3.5-turbo.",
    )
    return "gpt-3.5-turbo"
