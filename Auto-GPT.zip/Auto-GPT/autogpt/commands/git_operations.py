"""Команды для выполнения операций Git"""

COMMAND_CATEGORY = "git_operations"
COMMAND_CATEGORY_TITLE = "Git-Операции"

from git.repo import Repo

from autogpt.agents.agent import Agent
from autogpt.command_decorator import command
from autogpt.url_utils.validators import validate_url

from .decorators import sanitize_path_arg


@command(
    "clone_repository",
    "Клонирует Репозиторий",
    {
        "url": {
            "type": "string",
            "description": "URL репозитория для клонирования",
            "required": True,
        },
        "clone_path": {
            "type": "string",
            "description": "Путь для клонирования репозитория в",
            "required": True,
        },
    },
    lambda config: bool(config.github_username and config.github_api_key),
    "Настройте github_username и github_api_key.",
)
@sanitize_path_arg("clone_path")
@validate_url
def clone_repository(url: str, clone_path: str, agent: Agent) -> str:
    """Клонировать репозиторий GitHub локально.

    Args:
        url (str): The URL of the repository to clone.
        clone_path (str): The path to clone the repository to.

    Returns:
        str: The result of the clone operation.
    """
    split_url = url.split("//")
    auth_repo_url = (
        f"//{agent.config.github_username}:{agent.config.github_api_key}@".join(
            split_url
        )
    )
    try:
        Repo.clone_from(url=auth_repo_url, to_path=clone_path)
        return f"""Клонировано {url} в {clone_path}"""
    except Exception as e:
        return f"Ошибка: {str(e)}"
