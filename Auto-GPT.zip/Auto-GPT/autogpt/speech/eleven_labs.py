"""Речевой модуль ElevenLabs"""
from __future__ import annotations

import os
from typing import TYPE_CHECKING

import requests
from playsound import playsound

if TYPE_CHECKING:
    from autogpt.config import Config
from .base import VoiceBase

PLACEHOLDERS = {"your-voice-id"}


class ElevenLabsSpeech(VoiceBase):
    """Класс речи ElevenLabs"""

    def _setup(self, config: Config) -> None:
        """Настройте голоса, ключ API и т.д.

        Returns:
            None: None
        """

        default_voices = ["ErXwobaYiN019PkySvjV", "EXAVITQu4vr4xnSDxMaL"]
        voice_options = {
            "Rachel": "21m00Tcm4TlvDq8ikWAM",
            "Domi": "AZnzlk1XvdvUeBnXmlld",
            "Bella": "EXAVITQu4vr4xnSDxMaL",
            "Antoni": "ErXwobaYiN019PkySvjV",
            "Elli": "MF3mGyEYCl7XYWbV9V6O",
            "Josh": "TxGEqnHWrfWFTfGW9XjX",
            "Arnold": "VR6AewLTigWG4xSOukaG",
            "Adam": "pNInz6obpgDQGcFmaJgB",
            "Sam": "yoZ06aMxZJJ28mfd3POQ",
        }
        self._headers = {
            "Content-Type": "application/json",
            "xi-api-key": config.elevenlabs_api_key,
        }
        self._voices = default_voices.copy()
        if config.elevenlabs_voice_id in voice_options:
            config.elevenlabs_voice_id = voice_options[config.elevenlabs_voice_id]
        if config.elevenlabs_voice_2_id in voice_options:
            config.elevenlabs_voice_2_id = voice_options[config.elevenlabs_voice_2_id]
        self._use_custom_voice(config.elevenlabs_voice_id, 0)
        self._use_custom_voice(config.elevenlabs_voice_2_id, 1)

    def _use_custom_voice(self, voice, voice_index) -> None:
        """Используйте собственный голос, если он предоставлен, а не заполнитель

        Args:
            voice (str): Голосовой идентификатор
            voice_index (int): Индекс голоса

        Returns:
            None: None
        """
        # Значения-заполнители, которые следует рассматривать как пустые
        if voice and voice not in PLACEHOLDERS:
            self._voices[voice_index] = voice

    def _speech(self, text: str, voice_index: int = 0) -> bool:
        """Произносить текст с помощью API elevenlabs.io

        Args:
            text (str): The text to speak
            voice_index (int, optional): Голос, который нужно использовать. По умолчанию 0.

        Returns:
            bool: True, если запрос был успешным, False в противном случае
        """
        from autogpt.logs import logger

        tts_url = (
            f"https://api.elevenlabs.io/v1/text-to-speech/{self._voices[voice_index]}"
        )
        response = requests.post(tts_url, headers=self._headers, json={"text": text})

        if response.status_code == 200:
            with open("speech.mpeg", "wb") as f:
                f.write(response.content)
            playsound("speech.mpeg", True)
            os.remove("speech.mpeg")
            return True
        else:
            logger.warn("Запрос не выполнен с кодом состояния:", response.status_code)
            logger.info("Содержание ответа:", response.content)
            return False
