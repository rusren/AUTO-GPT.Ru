"""Команды для поиска в Интернете"""

from __future__ import annotations

COMMAND_CATEGORY = "web_search"
COMMAND_CATEGORY_TITLE = "Веб-поиск"

import json
import time
from itertools import islice

from duckduckgo_search import DDGS

from autogpt.agents.agent import Agent
from autogpt.command_decorator import command

DUCKDUCKGO_MAX_ATTEMPTS = 3


@command(
    "web_search",
    "Поиск в Интернете",
    {
        "query": {
            "type": "string",
            "description": "Поисковый запрос",
            "required": True,
        }
    },
    aliases=["search"],
)
def web_search(query: str, agent: Agent, num_results: int = 8) -> str:
    """Возврат результатов поиска Google

    Args:
        query (str): The search query.
        num_results (int): The number of results to return.

    Returns:
        str: The results of the search.
    """
    search_results = []
    attempts = 0

    while attempts < DUCKDUCKGO_MAX_ATTEMPTS:
        if not query:
            return json.dumps(search_results)

        results = DDGS().text(query)
        search_results = list(islice(results, num_results))

        if search_results:
            break

        time.sleep(1)
        attempts += 1

    results = json.dumps(search_results, ensure_ascii=False, indent=4)
    return safe_google_results(results)


@command(
    "google",
    "Google Search",
    {
        "query": {
            "type": "string",
            "description": "Поисковый запрос",
            "required": True,
        }
    },
    lambda config: bool(config.google_api_key)
    and bool(config.google_custom_search_engine_id),
    "Configure google_api_key and custom_search_engine_id.",
    aliases=["search"],
)
def google(query: str, agent: Agent, num_results: int = 8) -> str | list[str]:
    """Возврат результатов поиска Google с помощью официального API Google

    Args:
        query (str): The search query.
        num_results (int): The number of results to return.

    Returns:
        str: The results of the search.
    """

    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError

    try:
        # Получите ключ Google API и идентификатор системы пользовательского поиска из файла конфигурации.
        api_key = agent.config.google_api_key
        custom_search_engine_id = agent.config.google_custom_search_engine_id

        # Инициализировать службу API пользовательского поиска
        service = build("customsearch", "v1", developerKey=api_key)

        # Отправьте поисковый запрос и получите результаты
        result = (
            service.cse()
            .list(q=query, cx=custom_search_engine_id, num=num_results)
            .execute()
        )

        # Извлечение элементов результатов поиска из ответа
        search_results = result.get("items", [])

        # Создайте список только URL-адресов из результатов поиска
        search_results_links = [item["link"] for item in search_results]

    except HttpError as e:
        # Обработка ошибок в вызове API
        error_details = json.loads(e.content.decode())

        # Проверьте, не связана ли ошибка с недействительным или отсутствующим ключом API.
        if error_details.get("ошибка", {}).get(
            "кода"
        ) == 403 and "недействительный ключ API" in error_details.get("ошибка", {}).get(
            "сообщение", ""
        ):
            return "Ошибка: Предоставленный ключ Google API недействителен или отсутствует."
        else:
            return f"Ошибка: {e}"
    # google_result может быть списком или строкой в зависимости от результатов поиска

    # Вернуть список URL-адресов результатов поиска
    return safe_google_results(search_results_links)


def safe_google_results(results: str | list) -> str:
    """
        Возврат результатов поиска Google в безопасном формате.

    Args:
        results (str | list): The search results.

    Returns:
        str: The results of the search.
    """
    if isinstance(results, list):
        safe_message = json.dumps(
            [result.encode("utf-8", "игнорировать").decode("utf-8") for result in results]
        )
    else:
        safe_message = results.encode("utf-8", "игнорировать").decode("utf-8")
    return safe_message
