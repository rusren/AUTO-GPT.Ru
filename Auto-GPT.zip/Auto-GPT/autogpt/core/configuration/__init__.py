"""Конфигурация инкапсулирует настройки для всех подсистем Агента."""
from autogpt.core.configuration.schema import (
    Configurable,
    SystemConfiguration,
    SystemSettings,
    UserConfigurable,
)
