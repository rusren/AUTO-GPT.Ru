import argparse
import logging

from autogpt.commands.file_operations import ingest_file, list_files
from autogpt.config import ConfigBuilder
from autogpt.memory.vector import VectorMemory, get_memory

config = ConfigBuilder.build_config_from_env()


def configure_logging():
    logging.basicConfig(
        format="%(asctime)s,%(msecs)d %(name)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
        level=logging.DEBUG,
        handlers=[
            logging.FileHandler(filename="log-ingestion.txt", mode="a"),
            logging.StreamHandler(),
        ],
    )
    return logging.getLogger("AutoGPT-Ingestion")


def ingest_directory(directory: str, memory: VectorMemory, args):
    """
    Ingest all files in a directory by calling the ingest_file function for each file.

    :param directory: The directory containing the files to ingest
    :param memory: An object with an add() method to store the chunks in memory
    """
    logger = logging.getLogger("AutoGPT-Ingestion")
    try:
        files = list_files(directory)
        for file in files:
            ingest_file(file, memory, args.max_length, args.overlap)
    except Exception as e:
        logger.error(f"Ошибка при загрузке каталога '{directory}': {str(e)}")


def main() -> None:
    logger = configure_logging()

    parser = argparse.ArgumentParser(
        description="Загрузить файл или каталог с несколькими файлами в память. "
        "Обязательно установите свой .env перед запуском этого скрипта."
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--file", type=str, help="Файл для загрузки.")
    group.add_argument(
        "--dir", type=str, help="Каталог, содержащий файлы для загрузки."
    )
    parser.add_argument(
        "--init",
        action="store_true",
        help="Инициализировать память и стереть ее содержимое (по умолчанию: False)",
        default=False,
    )
    parser.add_argument(
        "--overlap",
        type=int,
        help="Размер перекрытия между чанками при загрузке файлов (по умолчанию: 200)",
        default=200,
    )
    parser.add_argument(
        "--max_length",
        type=int,
        help="The max_length of each chunk when ingesting files (default: 4000)",
        default=4000,
    )
    args = parser.parse_args()

    # Initialize memory
    memory = get_memory(config)
    if args.init:
        memory.clear()
    logger.debug("Использование памяти типа: " + memory.__class__.__name__)

    if args.file:
        try:
            ingest_file(args.file, memory, args.max_length, args.overlap)
            logger.info(f"Файл '{args.file}' успешно загружен.")
        except Exception as e:
            logger.error(f"Ошибка при загрузке файла '{args.file}': {str(e)}")
    elif args.dir:
        try:
            ingest_directory(args.dir, memory, args)
            logger.info(f"Каталог '{args.dir}' загружен успешно.")
        except Exception as e:
            logger.error(f"Ошибка при загрузке каталога '{args.dir}': {str(e)}")
    else:
        logger.warn(
            "В качестве входных данных укажите либо путь к файлу (--file), "
            "либо имя каталога (--dir) внутри каталога auto_gpt_workspace."
        )


if __name__ == "__main__":
    main()
